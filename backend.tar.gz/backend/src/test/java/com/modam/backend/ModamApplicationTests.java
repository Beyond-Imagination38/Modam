package com.modam.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.modam.backend.ModamApplication;

@SpringBootTest(classes = ModamApplication.class)
class ModamApplicationTests {

	@Test
	void contextLoads() {
	}

}
