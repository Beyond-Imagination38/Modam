backend/src/main/java/com/modam/backend/
├── controller/        컨트롤러 (API 요청 처리)
├── service/           서비스 (비즈니스 로직 처리)
├── repository/        DB 연동 (JPA)
├── model/             데이터 모델 (Entity)
├── dto/               요청/응답 DTO
├── config/            설정 파일